# Medplum Synthetic Data Sample

- **Project name:** Synthetic Data
- **Project ID:** `24d16fc3-9aaa-42c5-aa7f-716c55151540`
- **Cohort size:** 100 patients
- **Generated:** 2026-08-28T18:37:14Z

This archive is synthetic sample data. It does not contain PHI or PII.

## Contents

Resource types with no sampled rows are omitted. Every CSV, Parquet file, and SQLite table uses the same columns, ordered by `last_updated`, then `id`.

| Column | Type | Meaning |
| --- | --- | --- |
| `id` | `UUID` (`TEXT` in CSV/SQLite) | FHIR resource id; stable across history versions |
| `version_id` | `UUID` (`TEXT` in CSV/SQLite) | This history row’s version id (`meta.versionId`) |
| `content` | `TEXT` | Full FHIR JSON for that version (secrets stripped where noted below) |
| `last_updated` | `timestamp with time zone` (`TEXT` in CSV/SQLite) | `meta.lastUpdated` |
| `project_id` | `UUID` (TEXT in CSV/SQLite) | Medplum project id (`meta.project`) |

| Format | Files | How to use |
| --- | --- | --- |
| CSV | `*_History/<Table>_History.csv` | Spreadsheets, scripts, and tools that expect delimited text |
| Parquet | `*_History/<Table>_History.parquet` | Columnar analytics and warehouse loads. Easiest Snowflake import: follow [Loading and unloading Parquet data](https://docs.snowflake.com/en/user-guide/tutorials/script-data-load-transform-parquet). Snowflake does not import SQLite |
| SQLite | `history.sqlite` | Local SQL: one table per resource type, indexes on `id` and `last_updated`. Open with `sqlite3` or any SQLite client |

| Resource type | Number of Rows |
| --- | ---: |
| ActivityDefinition | 2 |
| AllergyIntolerance | 130 |
| AsyncJob | 200 |
| AuditEvent | 88 |
| Binary | 100 |
| ChargeItemDefinition | 1 |
| ClientApplication | 1 |
| Condition | 414 |
| Device | 100 |
| DiagnosticReport | 806 |
| MedicationRequest | 221 |
| Observation | 10799 |
| Patient | 100 |
| PlanDefinition | 100 |
| Practitioner | 1 |
| Procedure | 398 |
| Project | 5 |
| ProjectMembership | 6 |
| Questionnaire | 3 |
| ResearchSubject | 1 |
| ServiceRequest | 994 |
| Specimen | 994 |
| Task | 980 |
| UserSecurityRequest | 2 |

## Sampling

- Patients were chosen deterministically (md5 of Patient.id) from this project.
- Other resources were included when the current resource table's compartments array overlaps those patient IDs. All history versions of those IDs were kept.
- If a resource type had no cohort-linked rows, up to 100 project resource IDs were chosen deterministically as a fallback.
- Practitioner IDs referenced from exported JSON were added so Patient / Practitioner links are mostly intact. This is not full referential integrity.

## Secret redaction

These keys were removed from exported JSON (database rows were not changed):

- `User.passwordHash`
- `User.mfaSecret`
- `ClientApplication.secret`
- `IdentityProvider.clientSecret`
- `Project.secret`
- `Project.systemSecret`
- `Project.identityProvider.clientSecret`
